import os
import csv
import pandas as pd 
import statistics

#open csv file as budget_data
with open('/Users/shanaida/Desktop/python-challengeSZG/PyBank/Resources/budget_data.csv') as budget_data:
    readCSV = csv.reader(budget_data, delimiter=',')
    df = pd.read_csv('/Users/shanaida/Desktop/python-challengeSZG/PyBank/Resources/budget_data.csv')
#do not count header row
    firstrow = next(readCSV)
    total_months = []
    total_profitloss= []
#counts length of rows to count months which are on each row
    total_months = len(list(readCSV))
    print("total months are" + "" + str(total_months))
#Total Profit/Losses calculation
    total_profitloss=df['Profit/Losses'].sum()
    print(total_profitloss)
#Average change in profitloss  
    profitloss = df['Profit/Losses']
    average_change = []
    for i in range(total_months-1):
        average_change.append(profitloss[i+1]-profitloss[i])
    average_changeprofit= round(sum(average_change)/len(average_change),2)
    print(average_changeprofit)
#Max and Min for increase and decrease
    greatest_increase = max(average_change)
    greatest_decrease = min(average_change)
    print(greatest_increase)
    print(greatest_decrease)

#Max and min Month
    month = df['Date']
    ginc=average_change.index(greatest_increase)+1
    greatest_increase_month= []
    greatest_increase_month.append(month[ginc])
    gdec=average_change.index(greatest_decrease)+1  
    greatest_decrease_month= []
    greatest_decrease_month.append(month[gdec])

#Final print output for Budget Data
print("Financial Analysis")
print("----------------------------")
print(f"Total Months: {(total_months)}")
print(f"Total: ${(total_profitloss)}")
print(f"Average Change: {(average_changeprofit)}")
print(f"Greatest Increase in Profits: {str(greatest_increase_month)} (${(str(greatest_increase))})")
print(f"Greatest Decrease in Profits: {str(greatest_decrease_month)} (${(str(greatest_decrease))})")

#Text file creation    
output = open("FinancialAnalysis_Output.txt","w")
line1 = "Financial Analysis"
line2 = "---------------------"
line3 = str(f"Total Months: {(total_months)}")
line4 = str(f"Total: ${(total_profitloss)}")
line5 = str(f"Average Change: {(average_changeprofit)}")
line6 = str(f"Greatest Increase in Profits: {str(greatest_increase_month)} (${(str(greatest_increase))})")
line7 = str(f"Greatest Decrease in Profits: {str(greatest_decrease_month)} (${(str(greatest_decrease))})")
output.write('{}\n{}\n{}\n{}\n{}\n{}\n{}\n'.format(line1,line2,line3,line4,line5,line6,line7))