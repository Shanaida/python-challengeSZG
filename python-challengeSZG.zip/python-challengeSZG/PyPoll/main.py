import os
import csv
import pandas as pd 
import statistics

#read csv
with open('/Users/shanaida/Desktop/python-challengeSZG/PyPoll/Resources/election_data.csv') as election_data:
    readCSV = csv.reader(election_data, delimiter=',')
    df = pd.read_csv('/Users/shanaida/Desktop/python-challengeSZG/PyPoll/Resources/election_data.csv')
#do not count header row
    firstrow = next(readCSV)
#Total Votes Count
    total_votes=0
    for row in readCSV:
        total_votes += 1 
    print(total_votes)
#Unique Candidates
candidate_list=[]
candidates=df.Candidate.unique()
candidate_list.append(candidates)
#Percentage of Votes
candidate_votes={}
(candidate_votes[candidates]/total_votes)*100


    
    